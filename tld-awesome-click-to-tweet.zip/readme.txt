=== Plugin Name ===

Contributors: uriahs-victor
Plugin Name: TLD Awesome Click To Tweet
Plugin URI: https://github.com/UVLabs/tld-awesome-click-to-tweet
Tags: twitter, click to tweet, tweet intents, social media, social, tweet, twitter plugin, twitter widget, twitter boxes, tweet box, animated
Author URI: http://uriahsvictor.com
Author: Uriahs Victor (TheLoneDeveloper)
Requires at least: 4.1
Tested up to: 4.6
Stable tag: 1.0.0
Version: 1.0.0
License: GPLv2 of later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

A plugin for inserting tweet intents directly into posts or pages after any paragraph.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress


== Upgrade Notice ==

== Screenshots ==

1. Plugin UI on product page (button turned off).
2. Plugin UI on product page (button turned on).
3. Plugin Settings page.
4. Update email sent to buyers of the product.
5. Customable email body, more customization soon.

== Changelog ==

=1.0.0=

Initial release

== Frequently Asked Questions ==

More template?

I'm currently working on adding more templates to the plugin.

== Donations ==

Please use plugin's donate button on settings screen if you wish to donate, thank you.
