# TLD Awesome Click To Tweet
A plugin to embed tweet intents directly into your posts and pages via shortcode.

v1.0.0
